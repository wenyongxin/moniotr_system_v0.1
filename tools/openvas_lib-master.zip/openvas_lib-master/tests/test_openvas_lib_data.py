import unittest


class TestOpenVASPort(unittest.TestCase):
    pass
    # def test___init__(self):
    #     # open_vas_port = OpenVASPort(port_name, number, proto)
    #     assert False # TODO: implement your test here
    #
    # def test_number(self):
    #     # open_vas_port = OpenVASPort(port_name, number, proto)
    #     # self.assertEqual(expected, open_vas_port.number())
    #     assert False # TODO: implement your test here
    #
    # def test_port_name(self):
    #     # open_vas_port = OpenVASPort(port_name, number, proto)
    #     # self.assertEqual(expected, open_vas_port.port_name())
    #     assert False # TODO: implement your test here
    #
    # def test_proto(self):
    #     # open_vas_port = OpenVASPort(port_name, number, proto)
    #     # self.assertEqual(expected, open_vas_port.proto())
    #     assert False # TODO: implement your test here


class TestOpenVASNVT(unittest.TestCase):
    pass
    # def test___init__(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     assert False # TODO: implement your test here
    #
    # def test_bid(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.bid())
    #     assert False # TODO: implement your test here
    #
    # def test_bid_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.bid(val))
    #     assert False # TODO: implement your test here
    #
    # def test_bugtraq(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.bugtraq())
    #     assert False # TODO: implement your test here
    #
    # def test_bugtraq_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.bugtraq(val))
    #     assert False # TODO: implement your test here
    #
    # def test_category(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.category())
    #     assert False # TODO: implement your test here
    #
    # def test_category_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.category(val))
    #     assert False # TODO: implement your test here
    #
    # def test_cve(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.cve())
    #     assert False # TODO: implement your test here
    #
    # def test_cve_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.cve(val))
    #     assert False # TODO: implement your test here
    #
    # def test_cvss_base(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.cvss_base())
    #     assert False # TODO: implement your test here
    #
    # def test_cvss_base_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.cvss_base(val))
    #     assert False # TODO: implement your test here
    #
    # def test_description(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.raw_description())
    #     assert False # TODO: implement your test here
    #
    # def test_description_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.raw_description(val))
    #     assert False # TODO: implement your test here
    #
    # def test_family(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.family())
    #     assert False # TODO: implement your test here
    #
    # def test_family_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.family(val))
    #     assert False # TODO: implement your test here
    #
    # def test_fingerprints(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.fingerprints())
    #     assert False # TODO: implement your test here
    #
    # def test_fingerprints_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.fingerprints(val))
    #     assert False # TODO: implement your test here
    #
    # def test_make_object(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.make_object(oid, name, cvss_base, risk_factor, summary, raw_description, family, category, cve, bid, bugtraq, xrefs, fingerprints, tags))
    #     assert False # TODO: implement your test here
    #
    # def test_name(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.name())
    #     assert False # TODO: implement your test here
    #
    # def test_name_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.name(val))
    #     assert False # TODO: implement your test here
    #
    # def test_oid(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.oid())
    #     assert False # TODO: implement your test here
    #
    # def test_oid_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.oid(val))
    #     assert False # TODO: implement your test here
    #
    # def test_risk_factor(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.risk_factor())
    #     assert False # TODO: implement your test here
    #
    # def test_risk_factor_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.risk_factor(val))
    #     assert False # TODO: implement your test here
    #
    # def test_summary(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.summary())
    #     assert False # TODO: implement your test here
    #
    # def test_summary_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.summary(val))
    #     assert False # TODO: implement your test here
    #
    # def test_tags(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.tags())
    #     assert False # TODO: implement your test here
    #
    # def test_tags_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.tags(val))
    #     assert False # TODO: implement your test here
    #
    # def test_xrefs(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.xrefs())
    #     assert False # TODO: implement your test here
    #
    # def test_xrefs_case_2(self):
    #     # open_vasnv_t = OpenVASNVT()
    #     # self.assertEqual(expected, open_vasnv_t.xrefs(val))
    #     assert False # TODO: implement your test here


class TestOpenVASOverride(unittest.TestCase):
    pass
#     def test___init__(self):
#         # open_vas_override = OpenVASOverride()
#         assert False # TODO: implement your test here
#
#     def test_make_object(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.make_object(oid, name, text, text_is_excerpt, threat, new_threat, orphan))
#         assert False # TODO: implement your test here
#
#     def test_name(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.name())
#         assert False # TODO: implement your test here
#
#     def test_name_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.name(val))
#         assert False # TODO: implement your test here
#
#     def test_new_threat(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.new_threat())
#         assert False # TODO: implement your test here
#
#     def test_new_threat_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.new_threat(val))
#         assert False # TODO: implement your test here
#
#     def test_oid(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.oid())
#         assert False # TODO: implement your test here
#
#     def test_oid_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.oid(val))
#         assert False # TODO: implement your test here
#
#     def test_orphan(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.orphan())
#         assert False # TODO: implement your test here
#
#     def test_orphan_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.orphan(val))
#         assert False # TODO: implement your test here
#
#     def test_text(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.text())
#         assert False # TODO: implement your test here
#
#     def test_text_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.text(val))
#         assert False # TODO: implement your test here
#
#     def test_text_is_excerpt(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.text_is_excerpt())
#         assert False # TODO: implement your test here
#
#     def test_text_is_excerpt_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.text_is_excerpt(val))
#         assert False # TODO: implement your test here
#
#     def test_threat(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.threat())
#         assert False # TODO: implement your test here
#
#     def test_threat_case_2(self):
#         # open_vas_override = OpenVASOverride()
#         # self.assertEqual(expected, open_vas_override.threat(val))
#         assert False # TODO: implement your test here

class TestOpenVASNotes(unittest.TestCase):
    pass
#     def test___init__(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         assert False # TODO: implement your test here
#
#     def test_name(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         # self.assertEqual(expected, open_vas_notes.name())
#         assert False # TODO: implement your test here
#
#     def test_oid(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         # self.assertEqual(expected, open_vas_notes.oid())
#         assert False # TODO: implement your test here
#
#     def test_orphan(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         # self.assertEqual(expected, open_vas_notes.orphan())
#         assert False # TODO: implement your test here
#
#     def test_text(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         # self.assertEqual(expected, open_vas_notes.text())
#         assert False # TODO: implement your test here
#
#     def test_text_is_excerpt(self):
#         # open_vas_notes = OpenVASNotes(oid, name, text, text_is_excerpt, orphan)
#         # self.assertEqual(expected, open_vas_notes.text_is_excerpt())
#         assert False # TODO: implement your test here


class TestOpenVASResult(unittest.TestCase):
    pass
    # def test___init__(self):
    #     # open_vas_result = OpenVASResult()
    #     assert False # TODO: implement your test here
    #
    # def test_description(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.raw_description())
    #     assert False # TODO: implement your test here
    #
    # def test_description_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.raw_description(val))
    #     assert False # TODO: implement your test here
    #
    # def test_host(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.host())
    #     assert False # TODO: implement your test here
    #
    # def test_host_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.host(val))
    #     assert False # TODO: implement your test here
    #
    # def test_id(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.id())
    #     assert False # TODO: implement your test here
    #
    # def test_id_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.id(val))
    #     assert False # TODO: implement your test here
    #
    # def test_make_object(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.make_object(result_id, subnet, host, port, nvt, threat, raw_description, notes, overrides))
    #     assert False # TODO: implement your test here
    #
    # def test_notes(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.notes())
    #     assert False # TODO: implement your test here
    #
    # def test_notes_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.notes(val))
    #     assert False # TODO: implement your test here
    #
    # def test_nvt(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.nvt())
    #     assert False # TODO: implement your test here
    #
    # def test_nvt_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.nvt(val))
    #     assert False # TODO: implement your test here
    #
    # def test_overrides(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.overrides())
    #     assert False # TODO: implement your test here
    #
    # def test_overrides_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.overrides(val))
    #     assert False # TODO: implement your test here
    #
    # def test_port(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.port())
    #     assert False # TODO: implement your test here
    #
    # def test_port_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.port(val))
    #     assert False # TODO: implement your test here
    #
    # def test_subnet(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.subnet())
    #     assert False # TODO: implement your test here
    #
    # def test_subnet_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.subnet(val))
    #     assert False # TODO: implement your test here
    #
    # def test_threat(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.threat())
    #     assert False # TODO: implement your test here
    #
    # def test_threat_case_2(self):
    #     # open_vas_result = OpenVASResult()
    #     # self.assertEqual(expected, open_vas_result.threat(val))
    #     assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
