TODO
====

 - Implement commented unit test
 - Add support for new OMPv5
 - Update example.py
 - Add overrides and notes